(function () {
    "use strict";

    document.addEventListener("DOMContentLoaded", function () {

        var toggle = document.getElementById("theme-toggle");

        if (!toggle) {
            return;
        }

        /*
         * Each page gets its own theme.
         * Example:
         * sale.html     -> theme_sale
         * western.html  -> theme_western
         * index.html    -> theme_index
         */

        var pageName = window.location.pathname
            .split("/")
            .pop()
            .replace(".html", "");

        if (pageName === "") {
            pageName = "index";
        }

        var themeKey = "theme_" + pageName;


        /* Load saved theme for THIS page */

        var savedTheme = localStorage.getItem(themeKey);

        if (savedTheme === "dark") {

            document.body.classList.add("dark-mode");
            toggle.checked = true;

        } else {

            document.body.classList.remove("dark-mode");
            toggle.checked = false;

        }


        /* Toggle THIS page only */

        toggle.addEventListener("change", function () {

            if (toggle.checked) {

                document.body.classList.add("dark-mode");

                localStorage.setItem(themeKey, "dark");

            } else {

                document.body.classList.remove("dark-mode");

                localStorage.setItem(themeKey, "light");

            }

        });

    });

})();
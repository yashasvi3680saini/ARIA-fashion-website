let currentCaptcha = "";

// Random CAPTCHA generate karne ka logic
function generateCaptcha() {
  const chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
  let captcha = "";
  for (let i = 0; i < 6; i++) {
    captcha += chars.charAt(Math.floor(Math.random() * chars.length));
  }
  currentCaptcha = captcha;
  
  const captchaElement = document.getElementById("captcha-code");
  if (captchaElement) {
    captchaElement.innerText = captcha;
  }
}

// CAPTCHA Validate karne ka logic submit par
function validateCaptcha(event) {
  event.preventDefault();
  
  const userCaptcha = document.getElementById("captcha-input").value;
  const errorMsg = document.getElementById("captcha-error");

  if (userCaptcha !== currentCaptcha) {
    errorMsg.innerText = "Invalid CAPTCHA code. Try again!";
    generateCaptcha();
    document.getElementById("captcha-input").value = "";
    return false;
  } else {
    errorMsg.innerText = "";
    alert("Login successful!");
    return true;
  }
}

// Section Switcher (Navbar links handle karne ke liye)
function showSection(sectionId) {
  const homeSec = document.getElementById('home-section');
  const authSec = document.getElementById('auth-section');

  if (sectionId === 'home') {
    homeSec.style.display = 'block';
    authSec.style.display = 'none';
  } else if (sectionId === 'auth') {
    homeSec.style.display = 'none';
    authSec.style.display = 'flex';
  }
}

// Form Switcher (Login <-> Signup)
function switchForm(formType) {
  const loginForm = document.getElementById('login-form');
  const signupForm = document.getElementById('signup-form');
  const loginTabBtn = document.getElementById('login-tab-btn');
  const signupTabBtn = document.getElementById('signup-tab-btn');

  if (formType === 'login') {
    loginForm.classList.remove('hidden-form');
    loginForm.classList.add('active-form');
    
    signupForm.classList.remove('active-form');
    signupForm.classList.add('hidden-form');

    loginTabBtn.classList.add('active-tab');
    signupTabBtn.classList.remove('active-tab');
  } else if (formType === 'signup') {
    signupForm.classList.remove('hidden-form');
    signupForm.classList.add('active-form');

    loginForm.classList.remove('active-form');
    loginForm.classList.add('hidden-form');

    signupTabBtn.classList.add('active-tab');
    loginTabBtn.classList.remove('active-tab');
  }
}

// Dark / Light Theme Toggle Function
function toggleTheme() {
  const body = document.body;
  const themeIcon = document.getElementById('theme-icon');
  
  body.classList.toggle('dark-mode');
  
  if (body.classList.contains('dark-mode')) {
    themeIcon.innerText = '☀️';
  } else {
    themeIcon.innerText = '🌙';
  }
}

// Page load hone par default captcha set hoga
window.onload = function() {
  generateCaptcha();
};